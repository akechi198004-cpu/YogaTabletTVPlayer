# TouchIPTV V2 — Chromebook 触摸屏直播

已修复上一版的两个问题：**默认无源**、**触屏进入全屏后看不到退出按钮**。

## 启动（局域网）

1. Windows 电脑解压，双击 `启动服务_Windows.bat`。需 Python 3.9+（无需 pip 安装）。防火墙只允许“专用网络”。
2. 电脑打开 `http://localhost:8765`；Chromebook 连接同一局域网，在 Chrome 打开 `http://电脑IP:8765`。用 `ipconfig` 查看 Windows 电脑的 IPv4，**不要使用乐视电视的 192.168.0.105**。
3. 首次打开会自动读取三套预置公开 M3U（中国、中文、社区合并源）。读取成功后左侧出现频道，可搜索、按分类选台、收藏、切换备用线路。窄屏触摸左上角 `☰` 打开频道列表。
4. 即使远程订阅不可达，也有一条**HLS 播放功能测试（非直播）**用于验证播放器。此测试视频需要外网。

### 全屏怎么退出？

点视频区域上方 `⛶ 全屏`，进入全屏后，**视频右上角始终有一个「✕ 退出全屏」大按钮**，轻触退出。Chromebook 物理键盘也可按 `Esc`。本版还抑制视频控件的原生全屏按钮，避免进入没有网页退出按钮的另一种全屏模式。

### 频道怎么刷新？

按左侧 `↻ 刷新` 重新抓取已订阅的源。`☷ 订阅与导入` 可添加 M3U/TXT URL、导入本地文件、选择日本/国际订阅。误删全部订阅后点 `↻ 恢复预置频道源`。

## 预置订阅（非视频内容打包）

- https://iptv-org.github.io/iptv/countries/cn.m3u
- https://iptv-org.github.io/iptv/languages/zho.m3u
- https://raw.githubusercontent.com/JianghaoPi/my-tvbox-sources/main/output/live.m3u

这些是开放目录或社区聚合源的**订阅链接**，不是已经实测可播放的频道包。项目启动时需要运行服务的 **Windows 电脑** 能联网访问这些地址；频道流也可能因格式、版权、地区或运营商限制无法播放。并非所有源都具有公开转播授权，请只使用有权访问的节目。

## HLS 播放库

Chromebook 的 Chrome 播放直播 m3u8 通常需要 hls.js。包内 `hls.min.js` 是占位文件，网页会按需从外网 CDN 加载 hls.js。**本 ZIP 未内置该库的完整 JS 文件**。

如 Chromebook 无法访问 CDN，而 Windows 电脑可访问，可选运行 `下载HLS组件_Windows.bat`，把官方 hls.js 版本保存到项目目录，这样 Chrome 就可以从局域网使用本地库。下载后重新刷新网页；下载失败不会影响其它功能，但 Chrome 可能无法解码 HLS。无需运行该脚本也可以先测试。

## 技术范围与安全

- Python `server.py`：提供静态页面、代理公开 HTTP(S) M3U 与 HLS 清单、重写相对切片/密钥地址；屏蔽解析为非公网 IP 的目标。不能播放内网 UDP 组播、RTSP、DRM 或需要私有账号认证的源。
- 如果 M3U 可以导入但播放失败，先在“测试”分类选 HLS 测试视频排查；如果测试视频也失败，确认电脑到上游的联网情况及 hls.js 能否加载。
- 用户收藏与订阅保存在 Chromebook Chrome 的 localStorage。用另一台 Chromebook 打开同一页面不共享收藏。
- **只能用于可信家庭局域网。不要路由器映射 8765 端口，不要把服务器公开到互联网**；本地代理没有账号鉴权。
- 这里只做直播播放，没有远端节目许可检查；请尊重频道播出授权。

## 文件

`index.html`、`style.css`、`app.js`：静态页面和触摸界面；`server.py`：局域网服务器与代理；`tests/test_basic.py`：服务端自测；`下载HLS组件_Windows.bat`：可选下载播放器库。
