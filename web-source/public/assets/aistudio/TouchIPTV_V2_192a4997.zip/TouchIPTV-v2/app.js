(() => {
'use strict';
const $ = id => document.getElementById(id);
const KEY = 'touchiptv-v2';
// 首次启动即有频道订阅；地址为公开目录，并非承诺每个流均可以播放。
const STARTER_SUBS = [
  'https://iptv-org.github.io/iptv/countries/cn.m3u',
  'https://iptv-org.github.io/iptv/languages/zho.m3u',
  'https://raw.githubusercontent.com/JianghaoPi/my-tvbox-sources/main/output/live.m3u'
];
const DEMO = {name:'HLS 播放功能测试（非直播）',id:'touchiptv.demo',logo:'',group:'测试',url:'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',source:'官方示例测试视频'};
const defaults = {subs:[...STARTER_SUBS], fav:[], last:'', filter:'全部'};
let saved;
try {
  const fromV1 = JSON.parse(localStorage.getItem('touchiptv-v1') || '{}');
  const fromV2 = JSON.parse(localStorage.getItem(KEY) || 'null');
  saved = {...defaults,...fromV1,...(fromV2 || {})};
  // 升级到 V2 时，V1 空订阅表视为未初始化，自动载入预置源；V2 主动清空则保持清空。
  if (!fromV2 && (!Array.isArray(fromV1.subs) || fromV1.subs.length === 0)) saved.subs=[...STARTER_SUBS];
  if (!Array.isArray(saved.subs)) saved.subs=[...STARTER_SUBS];
  if (!Array.isArray(saved.fav)) saved.fav=[];
} catch { saved={...defaults}; }

let channels=[], current=null, activeLine=0, hls=null, query='', modalOpened=false, playingId=0;
const groups=['全部','收藏','央视','卫视','新闻','体育','影视','测试','其他'];
const persist=()=>localStorage.setItem(KEY,JSON.stringify(saved));
const message=t=>{$('notice').textContent=t;};
const state=t=>{$('sourceState').textContent=t;};
const isHls=u=>/\.m3u8(?:[?#]|$)/i.test(u)||/m3u8/i.test(u);
const safeUrl=u=>{try{let p=new URL(u);return ['http:','https:'].includes(p.protocol)?p.href:null}catch{return null}};
const base64Url=s=>{let bytes=new TextEncoder().encode(s);let a='';bytes.forEach(x=>a+=String.fromCharCode(x));return btoa(a).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')};
const viaProxy=url=>'/api/proxy?u='+encodeURIComponent(base64Url(url));
function classify(name, g=''){
  if(g==='测试')return '测试';
  const t=(name+' '+g).toLowerCase();
  if(/cctv|央视|中央电视/.test(t))return '央视';
  if(/卫视/.test(t))return '卫视';
  if(/新闻|news|财经|business|nhk world|bbc|dw |france 24/.test(t))return '新闻';
  if(/体育|sport|espn|nba/.test(t))return '体育';
  if(/电影|电视剧|影视|movie|cinema/.test(t))return '影视';
  return '其他';
}
function parseM3u(text,source){
  const lines=text.replace(/^\uFEFF/,'').split(/\r?\n/), result=[];let meta=null, txtGroup='';
  for(let raw of lines){let l=raw.trim();if(!l)continue;
    if(l.startsWith('#EXTINF')){let rest=l.slice(l.lastIndexOf(',')+1).trim();let attr=k=>{let m=l.match(new RegExp(k+'="([^"]*)"','i'));return m?m[1]:''};meta={name:rest||attr('tvg-name')||'未命名频道',id:attr('tvg-id'),logo:attr('tvg-logo'),group:attr('group-title')};continue}
    if(l.startsWith('#'))continue;
    if(l.endsWith(',#genre#')){txtGroup=l.slice(0,-8).trim();continue}
    if(l.includes(',')&&!meta){let split=l.indexOf(',');let name=l.slice(0,split).trim(), url=l.slice(split+1).trim();if(safeUrl(url))result.push({name,id:name,logo:'',group:classify(name,txtGroup),url,source});continue}
    let url=safeUrl(l);if(url){let info=meta||{name:'频道 '+(result.length+1),id:'',logo:'',group:''};result.push({...info,group:classify(info.name,info.group),url,source});meta=null}
  }
  return result;
}
function merge(arr){
  const map=new Map();let count=0;
  for(const item of arr){if(!item.url)continue;count++;
    const k=(item.id&&item.id.length>3?item.id:item.name).toLowerCase().replace(/[\s\u00b7_\-]/g,'');
    if(!map.has(k)){map.set(k,{...item,lines:[item.url]});continue}
    let prev=map.get(k);if(!prev.lines.includes(item.url))prev.lines.push(item.url);
    if(!prev.logo&&item.logo)prev.logo=item.logo;
  }
  return [...map.values()];
}
function renderFilters(){
  $('filters').innerHTML='';groups.forEach(g=>{let b=document.createElement('button');b.textContent=g;b.className=saved.filter===g?'selected':'';b.onclick=()=>{saved.filter=g;persist();renderFilters();renderChannels()};$('filters').append(b)})
}
function filtered(){return channels.filter(c=>{
  const match=!query||(c.name+' '+c.group).toLowerCase().includes(query);
  const matchGroup=saved.filter==='全部'||(saved.filter==='收藏'?saved.fav.includes(c.name):c.group===saved.filter);
  return match&&matchGroup;
})}
function renderChannels(){
  let list=filtered();$('resultCount').textContent=`${list.length} 个频道 · ${channels.length} 总计`;
  let host=$('channels');host.innerHTML='';let frag=document.createDocumentFragment();
  for(let item of list.slice(0,1000)){
    const b=document.createElement('button');b.className='channel'+(current?.name===item.name?' active':'');b.setAttribute('aria-label','播放 '+item.name);
    const av=document.createElement('div');av.className='avatar';av.textContent='TV';
    if(item.logo){let img=document.createElement('img');img.loading='lazy';img.referrerPolicy='no-referrer';img.src=item.logo;img.onerror=()=>img.remove();av.append(img)}
    const info=document.createElement('div');info.className='chaninfo';let name=document.createElement('b');name.textContent=item.name;let sub=document.createElement('small');sub.textContent=item.group+(item.lines.length>1?` · ${item.lines.length} 条线路`:'');info.append(name,sub);
    const star=document.createElement('span');star.className='star';star.textContent=saved.fav.includes(item.name)?'★':'☆';
    star.addEventListener('click',e=>{e.stopPropagation();toggleFav(item.name)});
    b.append(av,info,star);b.onclick=()=>play(item);frag.append(b);
  }
  host.append(frag);if(list.length>1000){let p=document.createElement('p');p.textContent='为保证触摸流畅，仅显示前1000条，请使用搜索筛选。';host.append(p)}
}
function toggleFav(name){saved.fav=saved.fav.includes(name)?saved.fav.filter(x=>x!==name):[...saved.fav,name];persist();renderChannels();updateFav()}
function updateFav(){$('favorite').textContent=(current&&saved.fav.includes(current.name)?'★ 已收藏':'☆ 收藏')}
function cleanup(){if(hls){hls.destroy();hls=null}let v=$('video');v.pause();v.removeAttribute('src');v.load()}
let hlsLoading=null;
async function ensureHls(){
 if(window.Hls)return true;
 if(!hlsLoading)hlsLoading=(async()=>{
   for(const url of ['https://cdn.jsdelivr.net/npm/hls.js@1.6.15/dist/hls.min.js','https://unpkg.com/hls.js@1.6.15/dist/hls.min.js']){
     try{await new Promise((resolve,reject)=>{let s=document.createElement('script');s.src=url;s.onload=resolve;s.onerror=reject;document.head.appendChild(s)});if(window.Hls)return true}catch{}
   }
   return false;
 })();
 return hlsLoading;
}
async function play(item,line=0){
  const thisPlay=++playingId;
  current=item;activeLine=line;saved.last=item.name;persist();renderChannels();updateFav();$('currentName').textContent=item.name;
  $('currentMeta').textContent=`${item.group} · 线路 ${line+1}/${item.lines.length} · ${item.source}`;
  $('empty').classList.add('hidden');$('loader').classList.remove('hidden');cleanup();
  let raw=item.lines[line],url=viaProxy(raw),v=$('video');
  const err=why=>{$('loader').classList.add('hidden');message(item.name+'：'+why+'。可以尝试「切换线路」，部分直播源可能失效、存在区域限制或不支持浏览器播放。')};
  v.onplaying=()=>{$('loader').classList.add('hidden');message('正在播放 '+item.name)};
  v.onerror=()=>err('浏览器无法播放这个流');
  if(isHls(raw)&&!window.Hls) {message('正在加载 HLS 播放组件（首次使用需要电脑可访问公共 CDN）…');await ensureHls();if(thisPlay!==playingId)return}
  let hlsAvail=window.Hls&&Hls.isSupported();
  if(isHls(raw)&&hlsAvail){hls=new Hls({enableWorker:true,lowLatencyMode:false,maxBufferLength:15,backBufferLength:15});hls.on(Hls.Events.ERROR,(_,data)=>{if(data.fatal && thisPlay===playingId){err(data.details||'HLS 播放失败');if(data.type===Hls.ErrorTypes.MEDIA_ERROR && hls)hls.recoverMediaError()}});hls.loadSource(url);hls.attachMedia(v);hls.on(Hls.Events.MANIFEST_PARSED,()=>v.play().catch(()=>{$('loader').classList.add('hidden');message('请触摸视频中的播放按钮开始播放') }));}
  else {v.src=isHls(raw)?url:url;v.play().catch(()=>{$('loader').classList.add('hidden');err(isHls(raw)?'HLS 解码库未就绪或浏览器不支持':'此编码或流格式不受 Chromebook 支持')})}
  if(window.innerWidth<=860)closeSidebar();
}
async function loadUrl(url){
 state('正在下载…');message('正在读取订阅 '+url);
 const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),24000);
 try{let res=await fetch('/api/load?url='+encodeURIComponent(url),{signal:abort.signal});if(!res.ok)throw Error('HTTP '+res.status);let txt=await res.text();let loaded=parseM3u(txt,url);if(!loaded.length)throw Error('没有解析到有效的 HTTP(S) 频道');
 const pre=channels.length;channels=merge([...channels,...loaded]);state(channels.length+' 个频道');renderChannels();message(`已载入 ${loaded.length} 条直播地址，合并后 ${channels.length} 个频道（原有 ${pre} 个）。尚未验证每条线路可播放。`);
 if(!saved.subs.includes(url)){saved.subs.push(url);persist()}renderSubs();return true;
 }catch(e){message('订阅加载失败：'+String(e.message||e)+'。如源受地区限制或已失效，可换源或导入本地 M3U。');state('载入失败');return false}finally{clearTimeout(timer)}
}
async function loadAll(){
  channels=merge([DEMO]);renderChannels();
  if(!saved.subs.length){state('仅有测试视频');message('订阅已清空。点「订阅与导入」恢复频道列表。');return}
  const subs=[...saved.subs];state('正在读取订阅 0/'+subs.length);
  let ok=0,failed=[];
  // 最多 3 条并发，任何一条加载失败也保留其他频道和内置测试片。
  await Promise.all(subs.map(async url=>{
    try{
      const res=await fetch('/api/load?url='+encodeURIComponent(url), {signal:AbortSignal.timeout ? AbortSignal.timeout(20000) : undefined});
      if(!res.ok)throw new Error('HTTP '+res.status);
      const txt=await res.text(), loaded=parseM3u(txt,url);
      if(!loaded.length)throw new Error('列表未包含 HTTP(S) 直播地址');
      channels=merge([...channels,...loaded]);ok++;
      state(channels.length-1+' 频道 · '+ok+'/'+subs.length+' 订阅');
      renderChannels();
      message('已加载 '+(channels.length-1)+' 个频道，来源 '+ok+'/'+subs.length+'；播放有效性仍需验证。');
    }catch(e){failed.push(url+' ('+(e.message||'失败')+')')}
  }));
  if(!ok){state('订阅载入失败');message('预置订阅全部下载失败。检查运行服务的电脑能否访问 GitHub/iptv-org；可用测试视频排查 HLS 解码，或点「订阅与导入」粘贴自己的 M3U。')}
  else if(failed.length){state((channels.length-1)+' 频道 · 部分源失败');message('已载入 '+(channels.length-1)+' 个频道；另有 '+failed.length+' 条订阅下载失败。失败可重试或在设置里换源。')}
  else{state((channels.length-1)+' 频道已载入');message('预置订阅已载入 '+(channels.length-1)+' 个频道。注意频道可列出不代表线路可播放；可尝试切换线路。')}
}

function renderSubs(){$('subscriptions').innerHTML='';for(let url of saved.subs){let div=document.createElement('div');div.className='subitem';let label=document.createElement('span');label.textContent=url;label.title=url;let btn=document.createElement('button');btn.textContent='移除';btn.onclick=()=>{saved.subs=saved.subs.filter(x=>x!==url);persist();renderSubs();message('已移除订阅，下次刷新生效。')};div.append(label,btn);$('subscriptions').append(div)}}
function openModal(){modalOpened=true;$('overlay').classList.remove('hidden');$('modal').classList.remove('hidden');renderSubs()}
function closeModal(){modalOpened=false;$('overlay').classList.add('hidden');$('modal').classList.add('hidden')}
function openSidebar(){$('sidebar').classList.add('open');$('overlay').classList.remove('hidden')}
function closeSidebar(){$('sidebar').classList.remove('open');if(!modalOpened)$('overlay').classList.add('hidden')}
$('search').addEventListener('input',e=>{query=e.target.value.trim().toLowerCase();renderChannels()});$('clearSearch').onclick=()=>{$('search').value='';query='';renderChannels()};
$('openSidebar').onclick=openSidebar;$('closeSidebar').onclick=closeSidebar;$('overlay').onclick=()=>{closeModal();closeSidebar()};
$('openSettings').onclick=()=>{closeSidebar();openModal()};$('closeSettings').onclick=closeModal;
$('refresh').onclick=loadAll;$('firstLoad').onclick=loadAll;$('quickSettings').onclick=openModal;
$('restorePresets').onclick=async()=>{saved.subs=[...new Set([...saved.subs,...STARTER_SUBS])];persist();renderSubs();closeModal();await loadAll();};
$('addUrl').onclick=async()=>{let url=safeUrl($('url').value.trim());if(!url){message('请输入有效的 http(s) M3U 订阅 URL');return}let ok=await loadUrl(url);if(ok){$('url').value='';closeModal()}};
document.querySelectorAll('.presets button').forEach(b=>b.onclick=async()=>{let ok=await loadUrl(b.dataset.url);if(ok)closeModal()});
$('file').onchange=async e=>{let f=e.target.files?.[0];if(!f)return;if(f.size>8*1024*1024){message('文件大于8MB，请换较小的列表');return}let parsed=parseM3u(await f.text(),'本地文件: '+f.name);channels=merge([...channels,...parsed]);state((channels.length-1)+' 个频道');renderChannels();closeModal();message('已导入 '+parsed.length+' 条地址（注意：本地导入仅保存在当前页面内存，刷新后需要重新导入）');e.target.value=''};
$('favorite').onclick=()=>current&&toggleFav(current.name);
$('nextLine').onclick=()=>{if(!current)return;play(current,(activeLine+1)%current.lines.length)};
$('retry').onclick=()=>current&&play(current,activeLine);
function syncFullscreen(){
  const active=document.fullscreenElement===$('playerFrame') || $('playerFrame').classList.contains('fullscreen-fallback');
  $('exitFullscreen').classList.toggle('hidden',!active);
  $('fullscreen').textContent=active?'✕ 退出':'⛶ 全屏';
  $('fullscreen').setAttribute('aria-label',active?'退出全屏':'进入全屏');
}
async function toggleFullscreen(forceExit=false){
  const frame=$('playerFrame');
  if(document.fullscreenElement){
    try{await document.exitFullscreen()}catch{};
  }else if(frame.classList.contains('fullscreen-fallback')){
    frame.classList.remove('fullscreen-fallback');document.body.classList.remove('fallback-fs');
  }else if(!forceExit){
    try{if(!frame.requestFullscreen)throw Error('Unsupported'); await frame.requestFullscreen()}
    catch{frame.classList.add('fullscreen-fallback');document.body.classList.add('fallback-fs')}
  }
  syncFullscreen();
}
$('fullscreen').onclick=()=>toggleFullscreen();
$('exitFullscreen').onclick=e=>{e.preventDefault();e.stopPropagation();toggleFullscreen(true)};
document.addEventListener('fullscreenchange',syncFullscreen);
document.addEventListener('webkitfullscreenchange',syncFullscreen);

document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();closeSidebar();if($('playerFrame').classList.contains('fullscreen-fallback'))toggleFullscreen(true)}if(e.target.tagName==='INPUT')return;if(e.key==='ArrowDown'||e.key==='ArrowUp'){let li=filtered(),i=li.findIndex(x=>x.name===current?.name);if(li.length){play(li[(i+(e.key==='ArrowDown'?1:-1)+li.length)%li.length]);e.preventDefault()}}});
channels=merge([DEMO]);renderFilters();renderChannels();renderSubs();syncFullscreen();if(saved.subs.length)loadAll();else state('等待订阅');
})();
