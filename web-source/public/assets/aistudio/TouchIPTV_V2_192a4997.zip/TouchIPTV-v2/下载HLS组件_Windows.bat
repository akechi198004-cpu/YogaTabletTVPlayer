@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $urls=@('https://cdn.jsdelivr.net/npm/hls.js@1.7.2/dist/hls.min.js','https://unpkg.com/hls.js@1.7.2/dist/hls.min.js'); $ok=$false; foreach($u in $urls){ try { Invoke-WebRequest -Uri $u -OutFile 'hls.tmp.js' -UseBasicParsing -TimeoutSec 12; if ((Get-Item 'hls.tmp.js').Length -gt 60000){Move-Item -Force 'hls.tmp.js' 'hls.min.js'; $ok=$true; break} } catch { Write-Host ('下载失败: '+$u) } }; if(Test-Path 'hls.tmp.js'){Remove-Item 'hls.tmp.js'}; if($ok){Write-Host 'HLS 组件已保存到 hls.min.js'}else{Write-Host '没有成功下载。可以继续用在线加载模式。';exit 1}"
pause
