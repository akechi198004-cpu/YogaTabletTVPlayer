from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
import threading, unittest, urllib.request, importlib.util

P = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('iptv_server',P/'server.py')
iptv = importlib.util.module_from_spec(spec);spec.loader.exec_module(iptv)

class SmokeTests(unittest.TestCase):
    def test_manifest_rewrite(self):
        result = iptv.rewrite_m3u8('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="key.bin"\nseg_1.ts\n', 'https://example.com/live/index.m3u8')
        self.assertIn('/api/proxy?u=', result)
        self.assertNotIn('URI="key.bin"', result)
        self.assertNotIn('\nseg_1.ts\n', result)

    def test_ui_and_assets(self):
        srv=iptv.ThreadingHTTPServer(('127.0.0.1',0),iptv.Handler)
        threading.Thread(target=srv.serve_forever,daemon=True).start()
        try:
            base='http://127.0.0.1:%d/'%srv.server_address[1]
            for path in ('','index.html','app.js','style.css'):
                with urllib.request.urlopen(base+path,timeout=3) as res:
                    self.assertEqual(res.status,200)
            with urllib.request.urlopen(base,timeout=3) as res:
                html=res.read().decode()
            self.assertIn('id="exitFullscreen"',html)
            self.assertIn('controlsList="nofullscreen"',html)
            self.assertIn('id="restorePresets"',html)
            js=(P/'app.js').read_text()
            self.assertIn('STARTER_SUBS',js)
            self.assertIn('document.addEventListener(\'fullscreenchange\'',js)
        finally:srv.shutdown();srv.server_close()

if __name__=='__main__':unittest.main()
