#!/usr/bin/env python3
"""TouchIPTV local-only-origin proxy; run only on a trusted home LAN."""
import base64, ipaddress, json, mimetypes, os, re, socket, sys, urllib.parse, urllib.request, urllib.error
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PORT = int(os.environ.get('IPTV_PORT', '8765'))
MAX_PLAYLIST = 8 * 1024 * 1024
MAX_MANIFEST = 4 * 1024 * 1024
HEADERS = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/125 Safari/537.36', 'Accept': '*/*'}

def encode(url):
    return base64.urlsafe_b64encode(url.encode()).decode().rstrip('=')

def decode(val):
    return base64.urlsafe_b64decode(val + '=' * (-len(val)%4)).decode()

def permitted(url):
    p = urllib.parse.urlsplit(url)
    if p.scheme not in ('http', 'https') or not p.hostname or p.username or p.password:
        return False
    hostname = p.hostname.lower().rstrip('.')
    if hostname in ('localhost','localhost.localdomain') or hostname.endswith(('.local','.localhost','.internal')):
        return False
    try:
        infos = socket.getaddrinfo(hostname, p.port or (443 if p.scheme=='https' else 80), type=socket.SOCK_STREAM)
        return bool(infos) and all(ipaddress.ip_address(x[4][0]).is_global for x in infos)
    except (OSError, ValueError):
        return False

class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not permitted(newurl): raise ValueError('Blocked redirect target')
        return super().redirect_request(req, fp, code, msg, headers, newurl)
OPENER = urllib.request.build_opener(SafeRedirect)

def rewrite_m3u8(text, base):
    lines = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith('#'):
            target = urllib.parse.urljoin(base, stripped)
            lines.append('/api/proxy?u=' + urllib.parse.quote(encode(target)))
        elif stripped.startswith('#'):
            def repl(m):
                target = urllib.parse.urljoin(base, m.group(2))
                return m.group(1) + '/api/proxy?u=' + urllib.parse.quote(encode(target)) + '"'
            lines.append(re.sub(r'(URI=")([^"]+)"', repl, line))
        else: lines.append(line)
    return '\n'.join(lines)+'\n'

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw): super().__init__(*a, directory=str(ROOT), **kw)
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin','*')
        self.send_header('X-Content-Type-Options','nosniff')
        super().end_headers()
    def respond(self,status,data,mime='text/plain; charset=utf-8'):
        self.send_response(status); self.send_header('Content-Type',mime); self.send_header('Content-Length',str(len(data))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        p = urllib.parse.urlsplit(self.path)
        if p.path not in ('/api/load','/api/proxy'):
            if p.path in ('/','/index.html','/app.js','/style.css','/hls.min.js','/favicon.svg'):
                return super().do_GET()
            return self.respond(404,b'Not found')
        q = urllib.parse.parse_qs(p.query)
        try:
            if p.path == '/api/load':
                url = q.get('url',[''])[0]
            else: url = decode(q.get('u',[''])[0])
            if not permitted(url): return self.respond(403,b'URL blocked (public http(s) only)')
            request_headers = dict(HEADERS)
            if p.path == '/api/proxy' and self.headers.get('Range'):
                request_headers['Range'] = self.headers['Range']
            req = urllib.request.Request(url,headers=request_headers)
            with OPENER.open(req, timeout=12) as res:
                status = res.status
                final = res.url
                if not permitted(final): return self.respond(403,b'Blocked target')
                ctype = res.headers.get('Content-Type','application/octet-stream')
                is_manifest = ('mpegurl' in ctype.lower() or urllib.parse.urlsplit(final).path.lower().endswith('.m3u8'))
                if p.path == '/api/load':
                    data = res.read(MAX_PLAYLIST+1)
                    if len(data)>MAX_PLAYLIST: return self.respond(413,b'Playlist too large')
                    return self.respond(200,data,'text/plain; charset=utf-8')
                if is_manifest:
                    data = res.read(MAX_MANIFEST+1)
                    if len(data)>MAX_MANIFEST: return self.respond(413,b'Manifest too large')
                    content = rewrite_m3u8(data.decode('utf-8-sig',errors='replace'), final).encode()
                    return self.respond(200,content,'application/vnd.apple.mpegurl')
                self.send_response(status)
                self.send_header('Content-Type',ctype)
                for h in ('Content-Range','Accept-Ranges','Content-Length'):
                    if res.headers.get(h): self.send_header(h,res.headers[h])
                self.send_header('Cache-Control','no-store')
                self.end_headers()
                while True:
                    chunk=res.read(128*1024)
                    if not chunk:break
                    try:self.wfile.write(chunk)
                    except (BrokenPipeError,ConnectionResetError):break
        except Exception as ex:
            try:self.respond(502,str(ex).encode('utf-8',errors='replace')[:512])
            except (BrokenPipeError, ConnectionResetError):pass
    def log_message(self, fmt, *args):
        print('%s - %s' % (self.address_string(),fmt % args),flush=True)

if __name__=='__main__':
    print(f'TouchIPTV at http://127.0.0.1:{PORT} and http://<PC-IP>:{PORT}')
    print('WARNING: For trusted home LAN only. Do not expose this port to the Internet.')
    ThreadingHTTPServer(('0.0.0.0',PORT),Handler).serve_forever()
